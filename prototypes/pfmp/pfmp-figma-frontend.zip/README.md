
  # Personal Finance Management Platform

  This is a code bundle for Personal Finance Management Platform. The original project is available at https://www.figma.com/design/uPgrZONp7v1BH0i9c1I4y6/Personal-Finance-Management-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  