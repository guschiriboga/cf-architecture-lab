import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { LoginPage } from './components/LoginPage';
import { Dashboard } from './components/Dashboard';
import { IncomesPage } from './components/IncomesPage';
import { ExpensesPage } from './components/ExpensesPage';
import { BankAccountsPage } from './components/BankAccountsPage';
import { CreditCardsPage } from './components/CreditCardsPage';
import { ProfilePage } from './components/ProfilePage';
import { SettingsPage } from './components/SettingsPage';

export type Page = 'dashboard' | 'incomes' | 'expenses' | 'bank-accounts' | 'credit-cards' | 'profile' | 'settings';

export interface IncomeOccurrence {
  id: string;
  date: string;
  expectedAmount: number;
  receivedAmount?: number;
  isConfirmed: boolean;
}

export interface Income {
  id: string;
  source: string;
  amount: number;
  frequency: 'monthly' | 'weekly' | 'yearly' | 'one-time';
  startDate: string;
  category: string;
  description?: string;
  occurrences: IncomeOccurrence[];
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
  paymentMethod: 'bank-transfer' | 'credit-card' | 'cash';
  paymentSourceId?: string; // ID of bank account or credit card
  linkedIncomeId?: string;
  familyMemberId?: string;
  isRecurring: boolean;
  frequency?: 'weekly' | 'monthly' | 'yearly';
  isPaid: boolean;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  balance: number;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountType: string;
  accountNumber: string;
  balance: number;
  currency: string;
  transactions: Transaction[];
}

export interface Payment {
  id: string;
  date: string;
  amount: number;
  description: string;
}

export interface CreditCard {
  id: string;
  cardName: string;
  last4Digits: string;
  creditLimit: number;
  currentBalance: number;
  dueDate: string;
  issuer: string;
  payments: Payment[];
  transactions: Transaction[];
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  currency: string;
  timezone: string;
}

export interface FamilyMember {
  id: string;
  name: string;
  relationship: string;
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  
  // Settings state
  const [categories, setCategories] = useState<string[]>([
    'Food',
    'Transportation',
    'Entertainment',
    'Utilities',
    'Housing',
    'Insurance',
    'Healthcare',
    'Shopping',
    'Education',
    'Other'
  ]);

  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([
    { id: '1', name: 'John Doe', relationship: 'Self' },
    { id: '2', name: 'Jane Doe', relationship: 'Spouse' }
  ]);

  const [accountTypes, setAccountTypes] = useState<string[]>([
    'Checking',
    'Savings',
    'Money Market',
    'Certificate of Deposit'
  ]);

  const [creditCardIssuers, setCreditCardIssuers] = useState<string[]>([
    'Visa',
    'Mastercard',
    'American Express',
    'Discover'
  ]);

  const [incomeCategories, setIncomeCategories] = useState<string[]>([
    'Salary',
    'Freelance',
    'Investment',
    'Business',
    'Gift',
    'Bonus',
    'Other'
  ]);

  const [incomeFrequencies, setIncomeFrequencies] = useState<string[]>([
    'weekly',
    'bi-weekly',
    'monthly',
    'quarterly',
    'yearly'
  ]);

  const [currencies, setCurrencies] = useState<string[]>([
    'USD',
    'EUR'
  ]);

  // Mock data
  const [incomes, setIncomes] = useState<Income[]>([
    {
      id: '1',
      source: 'Monthly Salary',
      amount: 5000,
      frequency: 'monthly',
      startDate: '2025-11-01',
      category: 'Salary',
      occurrences: [
        { id: 'o1', date: '2025-11-01', expectedAmount: 5000, receivedAmount: 5000, isConfirmed: true },
        { id: 'o2', date: '2025-12-01', expectedAmount: 5000, isConfirmed: false }
      ]
    },
    {
      id: '2',
      source: 'Freelance Project',
      amount: 1200,
      frequency: 'one-time',
      startDate: '2025-11-15',
      category: 'Freelance',
      occurrences: [
        { id: 'o3', date: '2025-11-15', expectedAmount: 1200, isConfirmed: false }
      ]
    }
  ]);

  const [expenses, setExpenses] = useState<Expense[]>([
    {
      id: '1',
      description: 'Grocery Shopping',
      amount: 150,
      category: 'Food',
      date: '2025-11-05',
      paymentMethod: 'credit-card',
      paymentSourceId: '1',
      isRecurring: false,
      isPaid: true
    },
    {
      id: '2',
      description: 'Netflix Subscription',
      amount: 15.99,
      category: 'Entertainment',
      date: '2025-11-01',
      paymentMethod: 'credit-card',
      paymentSourceId: '1',
      linkedIncomeId: '1',
      isRecurring: true,
      frequency: 'monthly',
      isPaid: true
    },
    {
      id: '3',
      description: 'Electricity Bill',
      amount: 85,
      category: 'Utilities',
      date: '2025-11-03',
      paymentMethod: 'bank-transfer',
      paymentSourceId: '1',
      isRecurring: true,
      frequency: 'monthly',
      isPaid: true
    },
    {
      id: '4',
      description: 'Rent',
      amount: 1500,
      category: 'Housing',
      date: '2025-11-10',
      paymentMethod: 'bank-transfer',
      paymentSourceId: '1',
      isRecurring: true,
      frequency: 'monthly',
      isPaid: false
    },
    {
      id: '5',
      description: 'Car Insurance',
      amount: 120,
      category: 'Insurance',
      date: '2025-11-15',
      paymentMethod: 'bank-transfer',
      paymentSourceId: '1',
      isRecurring: true,
      frequency: 'monthly',
      isPaid: false
    }
  ]);

  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([
    {
      id: '1',
      bankName: 'Chase Bank',
      accountType: 'Checking',
      accountNumber: '****1234',
      balance: 8500,
      currency: 'USD',
      transactions: [
        { id: 't1', date: '2025-11-07', description: 'Salary Deposit', amount: 5000, type: 'credit', balance: 8500 },
        { id: 't2', date: '2025-11-06', description: 'ATM Withdrawal', amount: 200, type: 'debit', balance: 3500 },
        { id: 't3', date: '2025-11-05', description: 'Grocery Store', amount: 150, type: 'debit', balance: 3700 },
        { id: 't4', date: '2025-11-04', description: 'Online Transfer', amount: 500, type: 'debit', balance: 3850 },
        { id: 't5', date: '2025-11-03', description: 'Electricity Bill', amount: 85, type: 'debit', balance: 4350 },
        { id: 't6', date: '2025-11-02', description: 'Coffee Shop', amount: 12.50, type: 'debit', balance: 4435 },
        { id: 't7', date: '2025-11-01', description: 'Netflix Subscription', amount: 15.99, type: 'debit', balance: 4447.50 },
        { id: 't8', date: '2025-10-31', description: 'Paycheck', amount: 5000, type: 'credit', balance: 4463.49 },
        { id: 't9', date: '2025-10-30', description: 'Restaurant', amount: 65, type: 'debit', balance: -536.51 },
        { id: 't10', date: '2025-10-29', description: 'Gas Station', amount: 45, type: 'debit', balance: -471.51 }
      ]
    },
    {
      id: '2',
      bankName: 'Wells Fargo',
      accountType: 'Savings',
      accountNumber: '****5678',
      balance: 15000,
      currency: 'USD',
      transactions: [
        { id: 't11', date: '2025-11-01', description: 'Interest Payment', amount: 25, type: 'credit', balance: 15000 },
        { id: 't12', date: '2025-10-15', description: 'Transfer from Checking', amount: 1000, type: 'credit', balance: 14975 },
        { id: 't13', date: '2025-10-01', description: 'Interest Payment', amount: 24, type: 'credit', balance: 13975 }
      ]
    }
  ]);

  const [creditCards, setCreditCards] = useState<CreditCard[]>([
    {
      id: '1',
      cardName: 'Chase Sapphire',
      last4Digits: '4532',
      creditLimit: 10000,
      currentBalance: 2500,
      dueDate: '2025-11-20',
      issuer: 'Visa',
      payments: [
        { id: 'p1', date: '2025-10-20', amount: 800, description: 'Monthly Payment' },
        { id: 'p2', date: '2025-09-20', amount: 1200, description: 'Monthly Payment' },
        { id: 'p3', date: '2025-08-20', amount: 950, description: 'Monthly Payment' },
        { id: 'p4', date: '2025-07-20', amount: 1100, description: 'Monthly Payment' }
      ],
      transactions: [
        { id: 't14', date: '2025-11-01', description: 'Grocery Store', amount: 150, type: 'debit', balance: 2350 },
        { id: 't15', date: '2025-10-31', description: 'Coffee Shop', amount: 12.50, type: 'debit', balance: 2337.50 },
        { id: 't16', date: '2025-10-30', description: 'Restaurant', amount: 65, type: 'debit', balance: 2272.50 }
      ]
    },
    {
      id: '2',
      cardName: 'American Express Gold',
      last4Digits: '8901',
      creditLimit: 15000,
      currentBalance: 13000,
      dueDate: '2025-11-25',
      issuer: 'Amex',
      payments: [
        { id: 'p5', date: '2025-10-25', amount: 600, description: 'Monthly Payment' },
        { id: 'p6', date: '2025-09-25', amount: 750, description: 'Monthly Payment' },
        { id: 'p7', date: '2025-08-25', amount: 500, description: 'Monthly Payment' }
      ],
      transactions: [
        { id: 't17', date: '2025-11-01', description: 'Grocery Store', amount: 150, type: 'debit', balance: 12850 },
        { id: 't18', date: '2025-10-31', description: 'Coffee Shop', amount: 12.50, type: 'debit', balance: 12837.50 },
        { id: 't19', date: '2025-10-30', description: 'Restaurant', amount: 65, type: 'debit', balance: 12772.50 }
      ]
    }
  ]);

  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    currency: 'USD',
    timezone: 'America/New_York'
  });

  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} onLogout={() => setIsLoggedIn(false)} />
      
      <main className="flex-1 overflow-y-auto">
        {currentPage === 'dashboard' && (
          <Dashboard
            incomes={incomes}
            expenses={expenses}
            bankAccounts={bankAccounts}
            creditCards={creditCards}
            setIncomes={setIncomes}
            setExpenses={setExpenses}
          />
        )}
        {currentPage === 'incomes' && (
          <IncomesPage 
            incomes={incomes} 
            setIncomes={setIncomes}
            categories={incomeCategories}
            currencies={currencies}
          />
        )}
        {currentPage === 'expenses' && (
          <ExpensesPage 
            expenses={expenses} 
            setExpenses={setExpenses}
            bankAccounts={bankAccounts}
            creditCards={creditCards}
            incomes={incomes}
            categories={categories}
            familyMembers={familyMembers}
          />
        )}
        {currentPage === 'bank-accounts' && (
          <BankAccountsPage 
            accounts={bankAccounts} 
            setAccounts={setBankAccounts}
            accountTypes={accountTypes}
            currencies={currencies}
          />
        )}
        {currentPage === 'credit-cards' && (
          <CreditCardsPage 
            cards={creditCards} 
            setCards={setCreditCards}
            issuers={creditCardIssuers}
            currencies={currencies}
          />
        )}
        {currentPage === 'profile' && (
          <ProfilePage profile={userProfile} setProfile={setUserProfile} />
        )}
        {currentPage === 'settings' && (
          <SettingsPage 
            categories={categories} 
            setCategories={setCategories}
            familyMembers={familyMembers}
            setFamilyMembers={setFamilyMembers}
            accountTypes={accountTypes}
            setAccountTypes={setAccountTypes}
            creditCardIssuers={creditCardIssuers}
            setCreditCardIssuers={setCreditCardIssuers}
            incomeCategories={incomeCategories}
            setIncomeCategories={setIncomeCategories}
            incomeFrequencies={incomeFrequencies}
            setIncomeFrequencies={setIncomeFrequencies}
            currencies={currencies}
            setCurrencies={setCurrencies}
          />
        )}
      </main>
    </div>
  );
}