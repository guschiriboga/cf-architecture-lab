import { useState } from 'react';
import { Expense, BankAccount, CreditCard, Income, FamilyMember } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { Plus, Pencil, Trash2, TrendingDown, RepeatIcon, CheckCircle, Clock, User, X, Filter } from 'lucide-react';
import { Badge } from './ui/badge';

interface ExpensesPageProps {
  expenses: Expense[];
  setExpenses: (expenses: Expense[]) => void;
  bankAccounts: BankAccount[];
  creditCards: CreditCard[];
  incomes: Income[];
  categories: string[];
  familyMembers: FamilyMember[];
}

export function ExpensesPage({ expenses, setExpenses, bankAccounts, creditCards, incomes, categories, familyMembers }: ExpensesPageProps) {
  const [isAddSheetOpen, setIsAddSheetOpen] = useState(false);
  const [isEditSheetOpen, setIsEditSheetOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [showAllFilters, setShowAllFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState<{
    categories: string[];
    familyMembers: string[];
    paymentMethods: string[];
    recurring: boolean | null;
    paid: boolean | null;
  }>({
    categories: [],
    familyMembers: [],
    paymentMethods: [],
    recurring: null,
    paid: null
  });
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    category: '',
    date: '',
    paymentMethod: 'cash' as Expense['paymentMethod'],
    paymentSourceId: '',
    linkedIncomeId: '',
    familyMemberId: '',
    isRecurring: false,
    frequency: 'monthly' as 'weekly' | 'monthly' | 'yearly'
  });

  const resetForm = () => {
    setFormData({
      description: '',
      amount: '',
      category: '',
      date: '',
      paymentMethod: 'cash',
      paymentSourceId: '',
      linkedIncomeId: '',
      familyMemberId: '',
      isRecurring: false,
      frequency: 'monthly'
    });
  };

  const handleAdd = () => {
    const newExpense: Expense = {
      id: Date.now().toString(),
      description: formData.description,
      amount: parseFloat(formData.amount),
      category: formData.category,
      date: formData.date,
      paymentMethod: formData.paymentMethod,
      paymentSourceId: formData.paymentSourceId || undefined,
      linkedIncomeId: formData.linkedIncomeId && formData.linkedIncomeId !== 'none' ? formData.linkedIncomeId : undefined,
      familyMemberId: formData.familyMemberId && formData.familyMemberId !== 'none' ? formData.familyMemberId : undefined,
      isRecurring: formData.isRecurring,
      frequency: formData.isRecurring ? formData.frequency : undefined,
      isPaid: false
    };
    setExpenses([...expenses, newExpense]);
    setIsAddSheetOpen(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!editingExpense) return;
    const updatedExpenses = expenses.map(expense =>
      expense.id === editingExpense.id
        ? {
            ...expense,
            description: formData.description,
            amount: parseFloat(formData.amount),
            category: formData.category,
            date: formData.date,
            paymentMethod: formData.paymentMethod,
            paymentSourceId: formData.paymentSourceId || undefined,
            linkedIncomeId: formData.linkedIncomeId && formData.linkedIncomeId !== 'none' ? formData.linkedIncomeId : undefined,
            familyMemberId: formData.familyMemberId && formData.familyMemberId !== 'none' ? formData.familyMemberId : undefined,
            isRecurring: formData.isRecurring,
            frequency: formData.isRecurring ? formData.frequency : undefined
          }
        : expense
    );
    setExpenses(updatedExpenses);
    setIsEditSheetOpen(false);
    setEditingExpense(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setExpenses(expenses.filter(expense => expense.id !== id));
  };

  const handleTogglePaid = (id: string) => {
    const updatedExpenses = expenses.map(expense =>
      expense.id === id ? { ...expense, isPaid: !expense.isPaid } : expense
    );
    setExpenses(updatedExpenses);
  };

  const openEditSheet = (expense: Expense) => {
    setEditingExpense(expense);
    setFormData({
      description: expense.description,
      amount: expense.amount.toString(),
      category: expense.category,
      date: expense.date,
      paymentMethod: expense.paymentMethod,
      paymentSourceId: expense.paymentSourceId || '',
      linkedIncomeId: expense.linkedIncomeId || 'none',
      familyMemberId: expense.familyMemberId || 'none',
      isRecurring: expense.isRecurring,
      frequency: expense.frequency || 'monthly'
    });
    setIsEditSheetOpen(true);
  };

  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const paidExpenses = expenses.filter(e => e.isPaid).reduce((sum, expense) => sum + expense.amount, 0);
  const unpaidExpenses = totalExpenses - paidExpenses;
  const recurringExpenses = expenses.filter(e => e.isRecurring).reduce((sum, e) => sum + e.amount, 0);

  const getPaymentSourceName = (expense: Expense) => {
    if (expense.paymentMethod === 'cash') return 'Cash';
    if (expense.paymentMethod === 'bank-transfer') {
      const account = bankAccounts.find(acc => acc.id === expense.paymentSourceId);
      return account ? `${account.bankName} ${account.accountNumber}` : 'Bank Transfer';
    }
    if (expense.paymentMethod === 'credit-card') {
      const card = creditCards.find(c => c.id === expense.paymentSourceId);
      return card ? `${card.cardName} ••${card.last4Digits}` : 'Credit Card';
    }
    return '';
  };

  const getLinkedIncomeName = (expense: Expense) => {
    if (!expense.linkedIncomeId) return null;
    const income = incomes.find(inc => inc.id === expense.linkedIncomeId);
    return income?.source;
  };

  const getFamilyMemberName = (expense: Expense) => {
    if (!expense.familyMemberId) return null;
    const member = familyMembers.find(m => m.id === expense.familyMemberId);
    return member?.name;
  };

  const applyFilters = (expenses: Expense[]) => {
    let filteredExpenses = expenses;
    if (activeFilters.categories.length > 0) {
      filteredExpenses = filteredExpenses.filter(expense => activeFilters.categories.includes(expense.category));
    }
    if (activeFilters.familyMembers.length > 0) {
      filteredExpenses = filteredExpenses.filter(expense => activeFilters.familyMembers.includes(expense.familyMemberId || 'none'));
    }
    if (activeFilters.paymentMethods.length > 0) {
      filteredExpenses = filteredExpenses.filter(expense => activeFilters.paymentMethods.includes(expense.paymentMethod));
    }
    if (activeFilters.recurring !== null) {
      filteredExpenses = filteredExpenses.filter(expense => expense.isRecurring === activeFilters.recurring);
    }
    if (activeFilters.paid !== null) {
      filteredExpenses = filteredExpenses.filter(expense => expense.isPaid === activeFilters.paid);
    }
    return filteredExpenses;
  };

  // Apply filters excluding the specific filter type to get accurate counts
  const getFilteredExpensesExcluding = (excludeFilter: 'categories' | 'familyMembers' | 'paymentMethods' | 'none' = 'none') => {
    let filteredExpenses = expenses;
    if (excludeFilter !== 'categories' && activeFilters.categories.length > 0) {
      filteredExpenses = filteredExpenses.filter(expense => activeFilters.categories.includes(expense.category));
    }
    if (excludeFilter !== 'familyMembers' && activeFilters.familyMembers.length > 0) {
      filteredExpenses = filteredExpenses.filter(expense => activeFilters.familyMembers.includes(expense.familyMemberId || 'none'));
    }
    if (excludeFilter !== 'paymentMethods' && activeFilters.paymentMethods.length > 0) {
      filteredExpenses = filteredExpenses.filter(expense => activeFilters.paymentMethods.includes(expense.paymentMethod));
    }
    if (activeFilters.recurring !== null) {
      filteredExpenses = filteredExpenses.filter(expense => expense.isRecurring === activeFilters.recurring);
    }
    if (activeFilters.paid !== null) {
      filteredExpenses = filteredExpenses.filter(expense => expense.isPaid === activeFilters.paid);
    }
    return filteredExpenses;
  };

  const filteredExpenses = applyFilters(expenses);

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Expense Management</h1>
          <p className="text-gray-600">Track and categorize your expenses</p>
        </div>
        <Dialog open={isAddSheetOpen} onOpenChange={setIsAddSheetOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Expense
            </Button>
          </DialogTrigger>
          <DialogContent className="overflow-y-auto max-w-2xl" aria-describedby={undefined}>
            <DialogHeader className="pb-4 border-b">
              <DialogTitle className="text-gray-900">Add New Expense</DialogTitle>
              <p className="text-sm text-gray-600 mt-2">Record a new expense transaction</p>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="description" className="text-gray-700">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="e.g., Grocery Shopping"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-gray-700">Amount</Label>
                <Input
                  id="amount"
                  type="number"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  placeholder="0.00"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category" className="text-gray-700">Category</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date" className="text-gray-700">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentMethod" className="text-gray-700">Payment Method</Label>
                <Select 
                  value={formData.paymentMethod} 
                  onValueChange={(value) => {
                    setFormData({ ...formData, paymentMethod: value as Expense['paymentMethod'], paymentSourceId: '' });
                  }}
                >
                  <SelectTrigger className="h-11">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="bank-transfer">Bank Transfer</SelectItem>
                    <SelectItem value="credit-card">Credit Card</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formData.paymentMethod === 'bank-transfer' && (
                <div className="space-y-2">
                  <Label htmlFor="bankAccount" className="text-gray-700">Bank Account</Label>
                  <Select value={formData.paymentSourceId} onValueChange={(value) => setFormData({ ...formData, paymentSourceId: value })}>
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Select bank account" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankAccounts.map(account => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.bankName} {account.accountNumber}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {formData.paymentMethod === 'credit-card' && (
                <div className="space-y-2">
                  <Label htmlFor="creditCard" className="text-gray-700">Credit Card</Label>
                  <Select value={formData.paymentSourceId} onValueChange={(value) => setFormData({ ...formData, paymentSourceId: value })}>
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Select credit card" />
                    </SelectTrigger>
                    <SelectContent>
                      {creditCards.map(card => (
                        <SelectItem key={card.id} value={card.id}>
                          {card.cardName} ••{card.last4Digits}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="linkedIncome" className="text-gray-700">Link to Income (Optional)</Label>
                <Select value={formData.linkedIncomeId} onValueChange={(value) => setFormData({ ...formData, linkedIncomeId: value })}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select income source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {incomes.map(income => (
                      <SelectItem key={income.id} value={income.id}>
                        {income.source}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="familyMember" className="text-gray-700">Family Member (Optional)</Label>
                <Select value={formData.familyMemberId} onValueChange={(value) => setFormData({ ...formData, familyMemberId: value })}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select family member" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {familyMembers.map(member => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.name} ({member.relationship})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox
                  id="isRecurring"
                  checked={formData.isRecurring}
                  onCheckedChange={(checked) => setFormData({ ...formData, isRecurring: checked as boolean })}
                />
                <Label htmlFor="isRecurring" className="cursor-pointer text-gray-700">This is a recurring expense</Label>
              </div>
              {formData.isRecurring && (
                <div className="space-y-2">
                  <Label htmlFor="frequency" className="text-gray-700">Frequency</Label>
                  <Select value={formData.frequency} onValueChange={(value) => setFormData({ ...formData, frequency: value as typeof formData.frequency })}>
                    <SelectTrigger className="h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <div className="pt-4 border-t">
              <Button 
                onClick={handleAdd} 
                className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
              >
                Add Expense
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Expense Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Expenses</p>
                <p className="text-2xl text-red-600">${totalExpenses.toLocaleString()}</p>
              </div>
              <div className="bg-red-100 text-red-600 p-3 rounded-lg">
                <TrendingDown className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Paid</p>
                <p className="text-2xl text-green-600">${paidExpenses.toLocaleString()}</p>
              </div>
              <div className="bg-green-100 text-green-600 p-3 rounded-lg">
                <CheckCircle className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Unpaid</p>
                <p className="text-2xl text-orange-600">${unpaidExpenses.toLocaleString()}</p>
              </div>
              <div className="bg-orange-100 text-orange-600 p-3 rounded-lg">
                <Clock className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Recurring</p>
                <p className="text-2xl text-purple-600">${recurringExpenses.toLocaleString()}</p>
              </div>
              <div className="bg-purple-100 text-purple-600 p-3 rounded-lg">
                <RepeatIcon className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Expenses List */}
      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            <CardTitle>All Expenses</CardTitle>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-600">{filteredExpenses.length} of {expenses.length}</span>
            </div>
          </div>
          
          {/* Quick Filters */}
          <div className="space-y-3">
            {!showAllFilters ? (
              /* Compact view - just tags with count > 0 */
              <div className="flex items-center gap-2 flex-wrap">
                {/* Category tags */}
                {categories
                  .filter(category => {
                    const count = getFilteredExpensesExcluding('categories').filter(e => e.category === category).length;
                    return count > 0;
                  })
                  .map(category => {
                    const isActive = activeFilters.categories.includes(category);
                    const count = getFilteredExpensesExcluding('categories').filter(e => e.category === category).length;
                    return (
                      <Badge
                        key={`cat-${category}`}
                        variant={isActive ? "default" : "outline"}
                        className={`cursor-pointer transition-all ${
                          isActive 
                            ? 'bg-blue-600 hover:bg-blue-700' 
                            : 'hover:bg-gray-100'
                        }`}
                        onClick={() => {
                          setActiveFilters(prev => ({
                            ...prev,
                            categories: isActive
                              ? prev.categories.filter(c => c !== category)
                              : [...prev.categories, category]
                          }));
                        }}
                      >
                        {category} ({count})
                        {isActive && <X className="w-3 h-3 ml-1" />}
                      </Badge>
                    );
                  })
                }
                
                {/* Family member tags */}
                {familyMembers
                  .filter(member => {
                    const count = getFilteredExpensesExcluding('familyMembers').filter(e => e.familyMemberId === member.id).length;
                    return count > 0;
                  })
                  .map(member => {
                    const isActive = activeFilters.familyMembers.includes(member.id);
                    const count = getFilteredExpensesExcluding('familyMembers').filter(e => e.familyMemberId === member.id).length;
                    return (
                      <Badge
                        key={`mem-${member.id}`}
                        variant={isActive ? "default" : "outline"}
                        className={`cursor-pointer transition-all ${
                          isActive 
                            ? 'bg-purple-600 hover:bg-purple-700' 
                            : 'hover:bg-gray-100'
                        }`}
                        onClick={() => {
                          setActiveFilters(prev => ({
                            ...prev,
                            familyMembers: isActive
                              ? prev.familyMembers.filter(m => m !== member.id)
                              : [...prev.familyMembers, member.id]
                          }));
                        }}
                      >
                        {member.name} ({count})
                        {isActive && <X className="w-3 h-3 ml-1" />}
                      </Badge>
                    );
                  })
                }
                
                {/* Payment method tags */}
                {(['cash', 'bank-transfer', 'credit-card'] as const).map(method => {
                  const isActive = activeFilters.paymentMethods.includes(method);
                  const count = getFilteredExpensesExcluding('paymentMethods').filter(e => e.paymentMethod === method).length;
                  const label = method === 'cash' ? 'Cash' : method === 'bank-transfer' ? 'Bank Transfer' : 'Credit Card';
                  if (count === 0) return null;
                  return (
                    <Badge
                      key={`pay-${method}`}
                      variant={isActive ? "default" : "outline"}
                      className={`cursor-pointer transition-all ${
                        isActive 
                          ? 'bg-green-600 hover:bg-green-700' 
                          : 'hover:bg-gray-100'
                      }`}
                      onClick={() => {
                        setActiveFilters(prev => ({
                          ...prev,
                          paymentMethods: isActive
                            ? prev.paymentMethods.filter(m => m !== method)
                            : [...prev.paymentMethods, method]
                        }));
                      }}
                    >
                      {label} ({count})
                      {isActive && <X className="w-3 h-3 ml-1" />}
                    </Badge>
                  );
                })}
                
                {/* Status tags */}
                <Badge
                  variant={activeFilters.recurring === true ? "default" : "outline"}
                  className={`cursor-pointer transition-all ${
                    activeFilters.recurring === true 
                      ? 'bg-orange-600 hover:bg-orange-700' 
                      : 'hover:bg-gray-100'
                  }`}
                  onClick={() => {
                    setActiveFilters(prev => ({
                      ...prev,
                      recurring: prev.recurring === true ? null : true
                    }));
                  }}
                >
                  Recurring ({expenses.filter(e => e.isRecurring).length})
                  {activeFilters.recurring === true && <X className="w-3 h-3 ml-1" />}
                </Badge>
                <Badge
                  variant={activeFilters.recurring === false ? "default" : "outline"}
                  className={`cursor-pointer transition-all ${
                    activeFilters.recurring === false 
                      ? 'bg-orange-600 hover:bg-orange-700' 
                      : 'hover:bg-gray-100'
                  }`}
                  onClick={() => {
                    setActiveFilters(prev => ({
                      ...prev,
                      recurring: prev.recurring === false ? null : false
                    }));
                  }}
                >
                  One-time ({expenses.filter(e => !e.isRecurring).length})
                  {activeFilters.recurring === false && <X className="w-3 h-3 ml-1" />}
                </Badge>
                <Badge
                  variant={activeFilters.paid === true ? "default" : "outline"}
                  className={`cursor-pointer transition-all ${
                    activeFilters.paid === true 
                      ? 'bg-teal-600 hover:bg-teal-700' 
                      : 'hover:bg-gray-100'
                  }`}
                  onClick={() => {
                    setActiveFilters(prev => ({
                      ...prev,
                      paid: prev.paid === true ? null : true
                    }));
                  }}
                >
                  Paid ({expenses.filter(e => e.isPaid).length})
                  {activeFilters.paid === true && <X className="w-3 h-3 ml-1" />}
                </Badge>
                <Badge
                  variant={activeFilters.paid === false ? "default" : "outline"}
                  className={`cursor-pointer transition-all ${
                    activeFilters.paid === false 
                      ? 'bg-teal-600 hover:bg-teal-700' 
                      : 'hover:bg-gray-100'
                  }`}
                  onClick={() => {
                    setActiveFilters(prev => ({
                      ...prev,
                      paid: prev.paid === false ? null : false
                    }));
                  }}
                >
                  Unpaid ({expenses.filter(e => !e.isPaid).length})
                  {activeFilters.paid === false && <X className="w-3 h-3 ml-1" />}
                </Badge>
                
                {/* Show all button */}
                <Badge
                  variant="outline"
                  className="cursor-pointer transition-all hover:bg-gray-100 border-dashed"
                  onClick={() => setShowAllFilters(true)}
                >
                  Show all filters
                </Badge>
              </div>
            ) : (
              /* Full view - organized in groups with all items */
              <>
                {/* Category Filters */}
                <div className="space-y-2">
                  <p className="text-xs text-gray-600">Categories</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {categories.map(category => {
                      const isActive = activeFilters.categories.includes(category);
                      const count = getFilteredExpensesExcluding('categories').filter(e => e.category === category).length;
                      return (
                        <Badge
                          key={category}
                          variant={isActive ? "default" : "outline"}
                          className={`cursor-pointer transition-all ${
                            isActive 
                              ? 'bg-blue-600 hover:bg-blue-700' 
                              : 'hover:bg-gray-100'
                          }`}
                          onClick={() => {
                            setActiveFilters(prev => ({
                              ...prev,
                              categories: isActive
                                ? prev.categories.filter(c => c !== category)
                                : [...prev.categories, category]
                            }));
                          }}
                        >
                          {category} ({count})
                          {isActive && <X className="w-3 h-3 ml-1" />}
                        </Badge>
                      );
                    })}
                  </div>
                </div>

                {/* Family Member Filters */}
                {familyMembers.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-600">Family Members</p>
                    <div className="flex items-center gap-2 flex-wrap">
                      {familyMembers.map(member => {
                        const isActive = activeFilters.familyMembers.includes(member.id);
                        const count = getFilteredExpensesExcluding('familyMembers').filter(e => e.familyMemberId === member.id).length;
                        return (
                          <Badge
                            key={member.id}
                            variant={isActive ? "default" : "outline"}
                            className={`cursor-pointer transition-all ${
                              isActive 
                                ? 'bg-purple-600 hover:bg-purple-700' 
                                : 'hover:bg-gray-100'
                            }`}
                            onClick={() => {
                              setActiveFilters(prev => ({
                                ...prev,
                                familyMembers: isActive
                                  ? prev.familyMembers.filter(m => m !== member.id)
                                  : [...prev.familyMembers, member.id]
                              }));
                            }}
                          >
                            {member.name} ({count})
                            {isActive && <X className="w-3 h-3 ml-1" />}
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Payment Method Filters */}
                <div className="space-y-2">
                  <p className="text-xs text-gray-600">Payment Methods</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {(['cash', 'bank-transfer', 'credit-card'] as const).map(method => {
                      const isActive = activeFilters.paymentMethods.includes(method);
                      const count = getFilteredExpensesExcluding('paymentMethods').filter(e => e.paymentMethod === method).length;
                      const label = method === 'cash' ? 'Cash' : method === 'bank-transfer' ? 'Bank Transfer' : 'Credit Card';
                      return (
                        <Badge
                          key={method}
                          variant={isActive ? "default" : "outline"}
                          className={`cursor-pointer transition-all ${
                            isActive 
                              ? 'bg-green-600 hover:bg-green-700' 
                              : 'hover:bg-gray-100'
                          }`}
                          onClick={() => {
                            setActiveFilters(prev => ({
                              ...prev,
                              paymentMethods: isActive
                                ? prev.paymentMethods.filter(m => m !== method)
                                : [...prev.paymentMethods, method]
                            }));
                          }}
                        >
                          {label} ({count})
                          {isActive && <X className="w-3 h-3 ml-1" />}
                        </Badge>
                      );
                    })}
                  </div>
                </div>

                {/* Status Filters */}
                <div className="space-y-2">
                  <p className="text-xs text-gray-600">Status</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge
                      variant={activeFilters.recurring === true ? "default" : "outline"}
                      className={`cursor-pointer transition-all ${
                        activeFilters.recurring === true 
                          ? 'bg-orange-600 hover:bg-orange-700' 
                          : 'hover:bg-gray-100'
                      }`}
                      onClick={() => {
                        setActiveFilters(prev => ({
                          ...prev,
                          recurring: prev.recurring === true ? null : true
                        }));
                      }}
                    >
                      Recurring ({expenses.filter(e => e.isRecurring).length})
                      {activeFilters.recurring === true && <X className="w-3 h-3 ml-1" />}
                    </Badge>
                    <Badge
                      variant={activeFilters.recurring === false ? "default" : "outline"}
                      className={`cursor-pointer transition-all ${
                        activeFilters.recurring === false 
                          ? 'bg-orange-600 hover:bg-orange-700' 
                          : 'hover:bg-gray-100'
                      }`}
                      onClick={() => {
                        setActiveFilters(prev => ({
                          ...prev,
                          recurring: prev.recurring === false ? null : false
                        }));
                      }}
                    >
                      One-time ({expenses.filter(e => !e.isRecurring).length})
                      {activeFilters.recurring === false && <X className="w-3 h-3 ml-1" />}
                    </Badge>
                    <Badge
                      variant={activeFilters.paid === true ? "default" : "outline"}
                      className={`cursor-pointer transition-all ${
                        activeFilters.paid === true 
                          ? 'bg-teal-600 hover:bg-teal-700' 
                          : 'hover:bg-gray-100'
                      }`}
                      onClick={() => {
                        setActiveFilters(prev => ({
                          ...prev,
                          paid: prev.paid === true ? null : true
                        }));
                      }}
                    >
                      Paid ({expenses.filter(e => e.isPaid).length})
                      {activeFilters.paid === true && <X className="w-3 h-3 ml-1" />}
                    </Badge>
                    <Badge
                      variant={activeFilters.paid === false ? "default" : "outline"}
                      className={`cursor-pointer transition-all ${
                        activeFilters.paid === false 
                          ? 'bg-teal-600 hover:bg-teal-700' 
                          : 'hover:bg-gray-100'
                      }`}
                      onClick={() => {
                        setActiveFilters(prev => ({
                          ...prev,
                          paid: prev.paid === false ? null : false
                        }));
                      }}
                    >
                      Unpaid ({expenses.filter(e => !e.isPaid).length})
                      {activeFilters.paid === false && <X className="w-3 h-3 ml-1" />}
                    </Badge>
                  </div>
                </div>
                
                {/* Hide button */}
                <Badge
                  variant="outline"
                  className="cursor-pointer transition-all hover:bg-gray-100 border-dashed"
                  onClick={() => setShowAllFilters(false)}
                >
                  Hide empty filters
                </Badge>
              </>
            )}

            {/* Clear All Filters */}
            {(activeFilters.categories.length > 0 || activeFilters.familyMembers.length > 0 || 
              activeFilters.paymentMethods.length > 0 || activeFilters.recurring !== null || 
              activeFilters.paid !== null) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActiveFilters({
                  categories: [],
                  familyMembers: [],
                  paymentMethods: [],
                  recurring: null,
                  paid: null
                })}
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Clear all filters
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredExpenses.length === 0 ? (
              <p className="text-center text-gray-500 py-8">No expenses recorded yet</p>
            ) : (
              filteredExpenses.map((expense) => (
                <div 
                  key={expense.id} 
                  className={`flex items-center justify-between p-4 rounded-lg border ${
                    expense.isPaid ? 'bg-gray-50 border-gray-200' : 'bg-yellow-50 border-yellow-200'
                  }`}
                >
                  <div className="flex items-center gap-3 flex-1">
                    <button
                      onClick={() => handleTogglePaid(expense.id)}
                      className={`flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                        expense.isPaid 
                          ? 'bg-green-500 border-green-500' 
                          : 'border-gray-300 hover:border-green-500'
                      }`}
                    >
                      {expense.isPaid && <CheckCircle className="w-4 h-4 text-white" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className={`text-gray-900 ${expense.isPaid ? 'line-through' : ''}`}>
                          {expense.description}
                        </p>
                        {expense.isRecurring && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                            <RepeatIcon className="w-3 h-3" />
                            {expense.frequency}
                          </span>
                        )}
                        {getFamilyMemberName(expense) && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                            <User className="w-3 h-3" />
                            {getFamilyMemberName(expense)}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-xs text-gray-600 flex-wrap">
                        <span>{expense.category}</span>
                        <span>•</span>
                        <span>{getPaymentSourceName(expense)}</span>
                        <span>•</span>
                        <span>{expense.date}</span>
                        {getLinkedIncomeName(expense) && (
                          <>
                            <span>•</span>
                            <span className="text-blue-600">Linked to: {getLinkedIncomeName(expense)}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 ml-4">
                    <p className="text-red-600">${expense.amount.toFixed(2)}</p>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEditSheet(expense)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(expense.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Edit Sheet */}
      <Dialog open={isEditSheetOpen} onOpenChange={setIsEditSheetOpen}>
        <DialogContent className="overflow-y-auto" aria-describedby={undefined}>
          <DialogHeader className="pb-4 border-b">
            <DialogTitle className="text-gray-900">Edit Expense</DialogTitle>
            <p className="text-sm text-gray-600 mt-2">Update the details of this expense</p>
          </DialogHeader>
          <div className="space-y-5 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-description" className="text-gray-700">Description</Label>
              <Input
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-amount" className="text-gray-700">Amount</Label>
              <Input
                id="edit-amount"
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-category" className="text-gray-700">Category</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-date" className="text-gray-700">Date</Label>
              <Input
                id="edit-date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-paymentMethod" className="text-gray-700">Payment Method</Label>
              <Select 
                value={formData.paymentMethod} 
                onValueChange={(value) => {
                  setFormData({ ...formData, paymentMethod: value as Expense['paymentMethod'], paymentSourceId: '' });
                }}
              >
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="bank-transfer">Bank Transfer</SelectItem>
                  <SelectItem value="credit-card">Credit Card</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {formData.paymentMethod === 'bank-transfer' && (
              <div className="space-y-2">
                <Label htmlFor="edit-bankAccount" className="text-gray-700">Bank Account</Label>
                <Select value={formData.paymentSourceId} onValueChange={(value) => setFormData({ ...formData, paymentSourceId: value })}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select bank account" />
                  </SelectTrigger>
                  <SelectContent>
                    {bankAccounts.map(account => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.bankName} {account.accountNumber}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {formData.paymentMethod === 'credit-card' && (
              <div className="space-y-2">
                <Label htmlFor="edit-creditCard" className="text-gray-700">Credit Card</Label>
                <Select value={formData.paymentSourceId} onValueChange={(value) => setFormData({ ...formData, paymentSourceId: value })}>
                  <SelectTrigger className="h-11">
                    <SelectValue placeholder="Select credit card" />
                  </SelectTrigger>
                  <SelectContent>
                    {creditCards.map(card => (
                      <SelectItem key={card.id} value={card.id}>
                        {card.cardName} ••{card.last4Digits}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="edit-linkedIncome" className="text-gray-700">Link to Income (Optional)</Label>
              <Select value={formData.linkedIncomeId} onValueChange={(value) => setFormData({ ...formData, linkedIncomeId: value })}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select income source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {incomes.map(income => (
                    <SelectItem key={income.id} value={income.id}>
                      {income.source}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-familyMember" className="text-gray-700">Family Member (Optional)</Label>
              <Select value={formData.familyMemberId} onValueChange={(value) => setFormData({ ...formData, familyMemberId: value })}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select family member" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {familyMembers.map(member => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.name} ({member.relationship})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Checkbox
                id="edit-isRecurring"
                checked={formData.isRecurring}
                onCheckedChange={(checked) => setFormData({ ...formData, isRecurring: checked as boolean })}
              />
              <Label htmlFor="edit-isRecurring" className="cursor-pointer text-gray-700">This is a recurring expense</Label>
            </div>
            {formData.isRecurring && (
              <div className="space-y-2">
                <Label htmlFor="edit-frequency" className="text-gray-700">Frequency</Label>
                <Select value={formData.frequency} onValueChange={(value) => setFormData({ ...formData, frequency: value as typeof formData.frequency })}>
                  <SelectTrigger className="h-11">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <div className="pt-4 border-t">
            <Button 
              onClick={handleEdit} 
              className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
            >
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}