import { useState } from 'react';
import { BankAccount } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Plus, Pencil, Trash2, Building2, ArrowUpCircle, ArrowDownCircle, Eye, DollarSign, ChevronDown, ChevronUp } from 'lucide-react';

interface BankAccountsPageProps {
  accounts: BankAccount[];
  setAccounts: (accounts: BankAccount[]) => void;
}

export function BankAccountsPage({ accounts, setAccounts }: BankAccountsPageProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isUpdateBalanceOpen, setIsUpdateBalanceOpen] = useState(false);
  const [selectedAccountForBalance, setSelectedAccountForBalance] = useState<BankAccount | null>(null);
  const [editingAccount, setEditingAccount] = useState<BankAccount | null>(null);
  const [expandedAccounts, setExpandedAccounts] = useState<Record<string, boolean>>({});
  const [showAllTransactions, setShowAllTransactions] = useState<Record<string, boolean>>({});
  const [newBalance, setNewBalance] = useState('');
  
  const [formData, setFormData] = useState({
    bankName: '',
    accountType: '',
    accountNumber: '',
    balance: '',
    currency: 'USD'
  });

  const resetForm = () => {
    setFormData({
      bankName: '',
      accountType: '',
      accountNumber: '',
      balance: '',
      currency: 'USD'
    });
  };

  const handleAdd = () => {
    const newAccount: BankAccount = {
      id: Date.now().toString(),
      bankName: formData.bankName,
      accountType: formData.accountType,
      accountNumber: formData.accountNumber,
      balance: parseFloat(formData.balance),
      currency: formData.currency,
      transactions: []
    };
    setAccounts([...accounts, newAccount]);
    setIsAddDialogOpen(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!editingAccount) return;
    const updatedAccounts = accounts.map(account =>
      account.id === editingAccount.id
        ? {
            ...account,
            bankName: formData.bankName,
            accountType: formData.accountType,
            accountNumber: formData.accountNumber,
            currency: formData.currency
          }
        : account
    );
    setAccounts(updatedAccounts);
    setIsEditDialogOpen(false);
    setEditingAccount(null);
    resetForm();
  };

  const handleUpdateBalance = () => {
    if (!selectedAccountForBalance) return;
    
    const balanceValue = parseFloat(newBalance);
    const oldBalance = selectedAccountForBalance.balance;
    const difference = balanceValue - oldBalance;
    
    const newTransaction: Transaction = {
      id: `t-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: 'Manual Balance Update',
      amount: Math.abs(difference),
      type: difference >= 0 ? 'credit' : 'debit',
      balance: balanceValue
    };

    const updatedAccounts = accounts.map(account =>
      account.id === selectedAccountForBalance.id
        ? {
            ...account,
            balance: balanceValue,
            transactions: [newTransaction, ...account.transactions]
          }
        : account
    );
    
    setAccounts(updatedAccounts);
    setIsUpdateBalanceOpen(false);
    setSelectedAccountForBalance(null);
    setNewBalance('');
  };

  const handleDelete = (id: string) => {
    setAccounts(accounts.filter(account => account.id !== id));
  };

  const openEditDialog = (account: BankAccount) => {
    setEditingAccount(account);
    setFormData({
      bankName: account.bankName,
      accountType: account.accountType,
      accountNumber: account.accountNumber,
      balance: account.balance.toString(),
      currency: account.currency
    });
    setIsEditDialogOpen(true);
  };

  const openUpdateBalanceDialog = (account: BankAccount) => {
    setSelectedAccountForBalance(account);
    setNewBalance(account.balance.toString());
    setIsUpdateBalanceOpen(true);
  };

  const toggleTransactions = (accountId: string) => {
    setShowAllTransactions(prev => ({
      ...prev,
      [accountId]: !prev[accountId]
    }));
  };

  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0);

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Bank Accounts</h1>
          <p className="text-gray-600">Manage your bank accounts and transactions</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg" aria-describedby={undefined}>
            <DialogHeader className="pb-4 border-b">
              <DialogTitle className="text-gray-900">Add New Bank Account</DialogTitle>
              <p className="text-sm text-gray-600 mt-2">Connect a new bank account to your profile</p>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="bankName" className="text-gray-700">Bank Name</Label>
                <Input
                  id="bankName"
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                  placeholder="e.g., Chase Bank"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountType" className="text-gray-700">Account Type</Label>
                <Input
                  id="accountType"
                  value={formData.accountType}
                  onChange={(e) => setFormData({ ...formData, accountType: e.target.value })}
                  placeholder="e.g., Checking, Savings"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountNumber" className="text-gray-700">Account Number</Label>
                <Input
                  id="accountNumber"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  placeholder="****1234"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="balance" className="text-gray-700">Balance</Label>
                <Input
                  id="balance"
                  type="number"
                  value={formData.balance}
                  onChange={(e) => setFormData({ ...formData, balance: e.target.value })}
                  placeholder="0.00"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency" className="text-gray-700">Currency</Label>
                <Input
                  id="currency"
                  value={formData.currency}
                  onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                  placeholder="USD"
                  className="h-11"
                />
              </div>
            </div>
            <div className="pt-4 border-t">
              <Button 
                onClick={handleAdd} 
                className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
              >
                Add Account
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Total Balance Card */}
      <Card className="mb-8 shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Balance</p>
              <p className="text-4xl text-blue-600">${totalBalance.toLocaleString()}</p>
              <p className="text-sm text-gray-500 mt-1">Across {accounts.length} account{accounts.length !== 1 ? 's' : ''}</p>
            </div>
            <div className="bg-blue-100 text-blue-600 p-4 rounded-lg">
              <Building2 className="w-8 h-8" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Accounts List */}
      <div className="space-y-6">
        {accounts.length === 0 ? (
          <Card className="shadow-sm">
            <CardContent className="p-12">
              <p className="text-center text-gray-500">No bank accounts added yet</p>
            </CardContent>
          </Card>
        ) : (
          accounts.map((account) => {
            const displayedTransactions = showAllTransactions[account.id] 
              ? account.transactions 
              : account.transactions.slice(0, 10);
            const isExpanded = expandedAccounts[account.id];
            
            return (
              <Card key={account.id} className="shadow-sm hover:shadow-md transition-shadow">
                {/* Compact header - always visible */}
                <CardContent className="p-5">
                  <div className="flex items-center justify-between">
                    {/* Left side: Icon, Name, Type, Number */}
                    <div className="flex items-center gap-3 flex-1">
                      <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                        <Building2 className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-gray-900">{account.bankName}</p>
                        <p className="text-sm text-gray-600">{account.accountType} • {account.accountNumber}</p>
                      </div>
                    </div>
                    
                    {/* Center: Balance */}
                    <div className="text-right mx-6">
                      <p className="text-sm text-gray-600 mb-1">Current Balance</p>
                      <p className="text-2xl text-blue-600">
                        {account.currency} ${account.balance.toLocaleString()}
                      </p>
                    </div>
                    
                    {/* Right side: Action buttons and expand arrow */}
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openUpdateBalanceDialog(account)}
                        title="Update Balance"
                      >
                        <DollarSign className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEditDialog(account)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(account.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      {account.transactions.length > 0 && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setExpandedAccounts(prev => ({
                            ...prev,
                            [account.id]: !prev[account.id]
                          }))}
                          className="ml-2"
                        >
                          <Eye className="w-5 h-5 text-gray-600" />
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Expandable Transactions Section */}
                  {isExpanded && account.transactions.length > 0 && (
                    <div className="mt-6 pt-6 border-t space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-600">Recent Transactions</p>
                        {account.transactions.length > 10 && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => toggleTransactions(account.id)}
                            className="text-blue-600"
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            {showAllTransactions[account.id] ? 'Show Less' : 'Show All'}
                          </Button>
                        )}
                      </div>
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {displayedTransactions.map((transaction) => (
                          <div 
                            key={transaction.id} 
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                          >
                            <div className="flex items-center gap-3 flex-1">
                              <div className={`p-2 rounded-lg ${
                                transaction.type === 'credit' 
                                  ? 'bg-green-100 text-green-600' 
                                  : 'bg-red-100 text-red-600'
                              }`}>
                                {transaction.type === 'credit' ? (
                                  <ArrowUpCircle className="w-4 h-4" />
                                ) : (
                                  <ArrowDownCircle className="w-4 h-4" />
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm text-gray-900 truncate">{transaction.description}</p>
                                <p className="text-xs text-gray-600">{transaction.date}</p>
                              </div>
                            </div>
                            <div className="text-right ml-4">
                              <p className={`text-sm ${
                                transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                              }`}>
                                {transaction.type === 'credit' ? '+' : '-'}${transaction.amount.toLocaleString()}
                              </p>
                              <p className="text-xs text-gray-600">
                                Bal: ${transaction.balance.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-lg" aria-describedby={undefined}>
          <DialogHeader className="pb-4 border-b">
            <DialogTitle className="text-gray-900">Edit Bank Account</DialogTitle>
            <p className="text-sm text-gray-600 mt-2">Update your bank account information</p>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-bankName" className="text-gray-700">Bank Name</Label>
              <Input
                id="edit-bankName"
                value={formData.bankName}
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-accountType" className="text-gray-700">Account Type</Label>
              <Input
                id="edit-accountType"
                value={formData.accountType}
                onChange={(e) => setFormData({ ...formData, accountType: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-accountNumber" className="text-gray-700">Account Number</Label>
              <Input
                id="edit-accountNumber"
                value={formData.accountNumber}
                onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-currency" className="text-gray-700">Currency</Label>
              <Input
                id="edit-currency"
                value={formData.currency}
                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                className="h-11"
              />
            </div>
          </div>
          <div className="pt-4 border-t">
            <Button 
              onClick={handleEdit} 
              className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
            >
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Update Balance Dialog */}
      <Dialog open={isUpdateBalanceOpen} onOpenChange={setIsUpdateBalanceOpen}>
        <DialogContent aria-describedby={undefined}>
          <DialogHeader className="pb-4 border-b">
            <DialogTitle className="text-gray-900">Update Account Balance</DialogTitle>
            <p className="text-sm text-gray-600 mt-2">Manually adjust the current balance</p>
          </DialogHeader>
          <div className="space-y-5 py-4">
            {selectedAccountForBalance && (
              <>
                <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-100">
                  <p className="text-sm text-gray-600 mb-1">Current Balance</p>
                  <p className="text-3xl text-blue-600">
                    ${selectedAccountForBalance.balance.toLocaleString()}
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newBalance" className="text-gray-700">New Balance</Label>
                  <Input
                    id="newBalance"
                    type="number"
                    value={newBalance}
                    onChange={(e) => setNewBalance(e.target.value)}
                    placeholder="Enter new balance"
                    className="h-11"
                  />
                </div>
              </>
            )}
          </div>
          <div className="pt-4 border-t">
            <Button 
              onClick={handleUpdateBalance} 
              className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
            >
              Update Balance
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}