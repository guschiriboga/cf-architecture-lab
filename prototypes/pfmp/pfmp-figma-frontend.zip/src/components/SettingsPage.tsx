import { useState } from 'react';
import { FamilyMember } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Plus, Trash2, Tag, Users, Building2, CreditCard as CreditCardIcon, DollarSign, Wallet, Clock } from 'lucide-react';

interface SettingsPageProps {
  categories: string[];
  setCategories: (categories: string[]) => void;
  familyMembers: FamilyMember[];
  setFamilyMembers: (members: FamilyMember[]) => void;
  accountTypes: string[];
  setAccountTypes: (types: string[]) => void;
  creditCardIssuers: string[];
  setCreditCardIssuers: (issuers: string[]) => void;
  incomeCategories: string[];
  setIncomeCategories: (categories: string[]) => void;
  incomeFrequencies: string[];
  setIncomeFrequencies: (frequencies: string[]) => void;
  currencies: string[];
  setCurrencies: (currencies: string[]) => void;
}

export function SettingsPage({ 
  categories, 
  setCategories, 
  familyMembers, 
  setFamilyMembers,
  accountTypes,
  setAccountTypes,
  creditCardIssuers,
  setCreditCardIssuers,
  incomeCategories,
  setIncomeCategories,
  incomeFrequencies,
  setIncomeFrequencies,
  currencies,
  setCurrencies
}: SettingsPageProps) {
  const [newCategory, setNewCategory] = useState('');
  const [newMember, setNewMember] = useState({ name: '', relationship: '' });
  const [newAccountType, setNewAccountType] = useState('');
  const [newCardIssuer, setNewCardIssuer] = useState('');
  const [newIncomeCategory, setNewIncomeCategory] = useState('');
  const [newIncomeFrequency, setNewIncomeFrequency] = useState('');
  const [newCurrency, setNewCurrency] = useState('');

  // Tab state
  const [primaryTab, setPrimaryTab] = useState<'categories' | 'parameters'>('categories');
  const [secondaryTab, setSecondaryTab] = useState<string>('expense-categories');

  // Update secondary tab when primary tab changes
  const handlePrimaryTabChange = (tab: 'categories' | 'parameters') => {
    setPrimaryTab(tab);
    if (tab === 'categories') {
      setSecondaryTab('expense-categories');
    } else {
      setSecondaryTab('account-types');
    }
  };

  const handleAddCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      setCategories([...categories, newCategory.trim()]);
      setNewCategory('');
    }
  };

  const handleDeleteCategory = (category: string) => {
    setCategories(categories.filter(c => c !== category));
  };

  const handleAddMember = () => {
    if (newMember.name.trim() && newMember.relationship.trim()) {
      const member: FamilyMember = {
        id: Date.now().toString(),
        name: newMember.name.trim(),
        relationship: newMember.relationship.trim()
      };
      setFamilyMembers([...familyMembers, member]);
      setNewMember({ name: '', relationship: '' });
    }
  };

  const handleDeleteMember = (id: string) => {
    setFamilyMembers(familyMembers.filter(m => m.id !== id));
  };

  const handleAddAccountType = () => {
    if (newAccountType.trim() && !accountTypes.includes(newAccountType.trim())) {
      setAccountTypes([...accountTypes, newAccountType.trim()]);
      setNewAccountType('');
    }
  };

  const handleDeleteAccountType = (type: string) => {
    setAccountTypes(accountTypes.filter(t => t !== type));
  };

  const handleAddCardIssuer = () => {
    if (newCardIssuer.trim() && !creditCardIssuers.includes(newCardIssuer.trim())) {
      setCreditCardIssuers([...creditCardIssuers, newCardIssuer.trim()]);
      setNewCardIssuer('');
    }
  };

  const handleDeleteCardIssuer = (issuer: string) => {
    setCreditCardIssuers(creditCardIssuers.filter(i => i !== issuer));
  };

  const handleAddIncomeCategory = () => {
    if (newIncomeCategory.trim() && !incomeCategories.includes(newIncomeCategory.trim())) {
      setIncomeCategories([...incomeCategories, newIncomeCategory.trim()]);
      setNewIncomeCategory('');
    }
  };

  const handleDeleteIncomeCategory = (category: string) => {
    setIncomeCategories(incomeCategories.filter(c => c !== category));
  };

  const handleAddIncomeFrequency = () => {
    if (newIncomeFrequency.trim() && !incomeFrequencies.includes(newIncomeFrequency.trim())) {
      setIncomeFrequencies([...incomeFrequencies, newIncomeFrequency.trim()]);
      setNewIncomeFrequency('');
    }
  };

  const handleDeleteIncomeFrequency = (frequency: string) => {
    setIncomeFrequencies(incomeFrequencies.filter(f => f !== frequency));
  };

  const handleAddCurrency = () => {
    if (newCurrency.trim() && !currencies.includes(newCurrency.trim().toUpperCase())) {
      setCurrencies([...currencies, newCurrency.trim().toUpperCase()]);
      setNewCurrency('');
    }
  };

  const handleDeleteCurrency = (currency: string) => {
    setCurrencies(currencies.filter(c => c !== currency));
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-gray-900 mb-1">Settings</h1>
        <p className="text-gray-600">Manage your personalized categories and parameters</p>
      </div>

      {/* Primary Tabs */}
      <div className="mb-6">
        <div className="flex gap-2 border-b border-gray-200">
          <button
            onClick={() => handlePrimaryTabChange('categories')}
            className={`px-4 py-2.5 text-sm transition-colors relative ${
              primaryTab === 'categories'
                ? 'text-white bg-gradient-to-r from-blue-600 to-purple-600 rounded-t'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
            }`}
          >
            Categories / Tags
          </button>
          <button
            onClick={() => handlePrimaryTabChange('parameters')}
            className={`px-4 py-2.5 text-sm transition-colors relative ${
              primaryTab === 'parameters'
                ? 'text-white bg-gradient-to-r from-blue-600 to-purple-600 rounded-t'
                : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
            }`}
          >
            Parameters
          </button>
        </div>
      </div>

      {/* Secondary Tabs */}
      <div className="mb-6">
        <div className="flex gap-2 border-b border-gray-200">
          {primaryTab === 'categories' ? (
            <>
              <button
                onClick={() => setSecondaryTab('expense-categories')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'expense-categories'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Expense Categories
              </button>
              <button
                onClick={() => setSecondaryTab('family-members')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'family-members'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Family Members
              </button>
              <button
                onClick={() => setSecondaryTab('income-categories')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'income-categories'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Income Categories
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setSecondaryTab('account-types')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'account-types'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Account Types
              </button>
              <button
                onClick={() => setSecondaryTab('credit-card-issuers')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'credit-card-issuers'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Credit Card Issuers
              </button>
              <button
                onClick={() => setSecondaryTab('income-frequencies')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'income-frequencies'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Income Frequencies
              </button>
              <button
                onClick={() => setSecondaryTab('currencies')}
                className={`px-4 py-2 text-sm transition-colors ${
                  secondaryTab === 'currencies'
                    ? 'text-blue-700 bg-blue-50 border-b-2 border-blue-600 rounded-t'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-t'
                }`}
              >
                Currencies
              </button>
            </>
          )}
        </div>
      </div>

      {/* Content Area */}
      <div className="max-w-2xl">
        {/* Expense Categories */}
        {secondaryTab === 'expense-categories' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-blue-600" />
                Expense Categories
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Manage categories to organize your expenses
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Enter new category name"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddCategory()}
                  />
                </div>
                <Button
                  onClick={handleAddCategory}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                {categories.map((category) => (
                  <div
                    key={category}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-2">
                      <Tag className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-900">{category}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteCategory(category)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {categories.length === 0 && (
                <p className="text-center text-gray-500 py-8">No categories added yet</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Family Members */}
        {secondaryTab === 'family-members' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Family Members
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Add family members to link them with expenses
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Input
                    placeholder="Name"
                    value={newMember.name}
                    onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                  />
                </div>
                <div>
                  <Input
                    placeholder="Relationship"
                    value={newMember.relationship}
                    onChange={(e) => setNewMember({ ...newMember, relationship: e.target.value })}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddMember()}
                  />
                </div>
              </div>
              <Button
                onClick={handleAddMember}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>

              <div className="space-y-2 max-h-96 overflow-y-auto">
                {familyMembers.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <Users className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-gray-900">{member.name}</p>
                        <p className="text-sm text-gray-600">{member.relationship}</p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteMember(member.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {familyMembers.length === 0 && (
                <p className="text-center text-gray-500 py-8">No family members added yet</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Income Categories */}
        {secondaryTab === 'income-categories' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-blue-600" />
                Income Categories
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Manage categories to organize your income
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Enter new income category"
                    value={newIncomeCategory}
                    onChange={(e) => setNewIncomeCategory(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddIncomeCategory()}
                  />
                </div>
                <Button
                  onClick={handleAddIncomeCategory}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                {incomeCategories.map((category) => (
                  <div
                    key={category}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-900">{category}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteIncomeCategory(category)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {incomeCategories.length === 0 && (
                <p className="text-center text-gray-500 py-8">No income categories added yet</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Account Types */}
        {secondaryTab === 'account-types' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Account Types
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Manage account types for your financial accounts
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Enter new account type"
                    value={newAccountType}
                    onChange={(e) => setNewAccountType(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddAccountType()}
                  />
                </div>
                <Button
                  onClick={handleAddAccountType}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                {accountTypes.map((type) => (
                  <div
                    key={type}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-900">{type}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteAccountType(type)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {accountTypes.length === 0 && (
                <p className="text-center text-gray-500 py-8">No account types added yet</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Credit Card Issuers */}
        {secondaryTab === 'credit-card-issuers' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCardIcon className="w-5 h-5 text-blue-600" />
                Credit Card Issuers
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Manage credit card issuers for your financial accounts
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Enter new card issuer"
                    value={newCardIssuer}
                    onChange={(e) => setNewCardIssuer(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddCardIssuer()}
                  />
                </div>
                <Button
                  onClick={handleAddCardIssuer}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                {creditCardIssuers.map((issuer) => (
                  <div
                    key={issuer}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-2">
                      <CreditCardIcon className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-900">{issuer}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteCardIssuer(issuer)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {creditCardIssuers.length === 0 && (
                <p className="text-center text-gray-500 py-8">No card issuers added yet</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Income Frequencies */}
        {secondaryTab === 'income-frequencies' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600" />
                Income Frequencies
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Manage frequencies for your recurring income
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Enter new frequency"
                    value={newIncomeFrequency}
                    onChange={(e) => setNewIncomeFrequency(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddIncomeFrequency()}
                  />
                </div>
                <Button
                  onClick={handleAddIncomeFrequency}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                {incomeFrequencies.map((frequency) => (
                  <div
                    key={frequency}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-900">{frequency}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteIncomeFrequency(frequency)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {incomeFrequencies.length === 0 && (
                <p className="text-center text-gray-500 py-8">No frequencies added yet</p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Currencies */}
        {secondaryTab === 'currencies' && (
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-blue-600" />
                Currencies
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Manage currencies for your financial accounts
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <div className="flex-1">
                  <Input
                    placeholder="Enter currency code (e.g., USD)"
                    value={newCurrency}
                    onChange={(e) => setNewCurrency(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddCurrency()}
                  />
                </div>
                <Button
                  onClick={handleAddCurrency}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 gap-2 max-h-96 overflow-y-auto">
                {currencies.map((currency) => (
                  <div
                    key={currency}
                    className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center gap-2">
                      <Wallet className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-900">{currency}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteCurrency(currency)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              {currencies.length === 0 && (
                <p className="text-center text-gray-500 py-8">No currencies added yet</p>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}