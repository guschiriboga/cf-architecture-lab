import { useState } from 'react';
import { CreditCard, Transaction } from '../App';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Plus, Pencil, Trash2, CreditCard as CreditCardIcon, AlertCircle, Eye, TrendingDown, ArrowUpCircle, ArrowDownCircle, Calendar } from 'lucide-react';

interface CreditCardsPageProps {
  cards: CreditCard[];
  setCards: (cards: CreditCard[]) => void;
}

export function CreditCardsPage({ cards, setCards }: CreditCardsPageProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<CreditCard | null>(null);
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({});
  const [showAllHistory, setShowAllHistory] = useState<Record<string, boolean>>({});
  
  const [formData, setFormData] = useState({
    cardName: '',
    last4Digits: '',
    creditLimit: '',
    currentBalance: '',
    dueDate: '',
    issuer: ''
  });

  const resetForm = () => {
    setFormData({
      cardName: '',
      last4Digits: '',
      creditLimit: '',
      currentBalance: '',
      dueDate: '',
      issuer: ''
    });
  };

  const handleAdd = () => {
    const newCard: CreditCard = {
      id: Date.now().toString(),
      cardName: formData.cardName,
      last4Digits: formData.last4Digits,
      creditLimit: parseFloat(formData.creditLimit),
      currentBalance: parseFloat(formData.currentBalance),
      dueDate: formData.dueDate,
      issuer: formData.issuer,
      payments: [],
      transactions: []
    };
    setCards([...cards, newCard]);
    setIsAddDialogOpen(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!editingCard) return;
    
    const oldBalance = editingCard.currentBalance;
    const newBalanceValue = parseFloat(formData.currentBalance);
    const difference = newBalanceValue - oldBalance;
    
    // Create a transaction if balance changed
    let newTransaction: Transaction | null = null;
    if (difference !== 0) {
      newTransaction = {
        id: `t-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        description: 'Manual Balance Update',
        amount: Math.abs(difference),
        type: difference >= 0 ? 'debit' : 'credit', // debit increases balance, credit decreases
        balance: newBalanceValue
      };
    }
    
    const updatedCards = cards.map(card =>
      card.id === editingCard.id
        ? {
            ...card,
            cardName: formData.cardName,
            last4Digits: formData.last4Digits,
            creditLimit: parseFloat(formData.creditLimit),
            currentBalance: newBalanceValue,
            dueDate: formData.dueDate,
            issuer: formData.issuer,
            transactions: newTransaction ? [newTransaction, ...card.transactions] : card.transactions
          }
        : card
    );
    setCards(updatedCards);
    setIsEditDialogOpen(false);
    setEditingCard(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setCards(cards.filter(card => card.id !== id));
  };

  const openEditDialog = (card: CreditCard) => {
    setEditingCard(card);
    setFormData({
      cardName: card.cardName,
      last4Digits: card.last4Digits,
      creditLimit: card.creditLimit.toString(),
      currentBalance: card.currentBalance.toString(),
      dueDate: card.dueDate,
      issuer: card.issuer
    });
    setIsEditDialogOpen(true);
  };

  const toggleHistory = (cardId: string) => {
    setShowAllHistory(prev => ({
      ...prev,
      [cardId]: !prev[cardId]
    }));
  };

  const totalCreditUsed = cards.reduce((sum, card) => sum + card.currentBalance, 0);
  const totalCreditLimit = cards.reduce((sum, card) => sum + card.creditLimit, 0);
  const availableCredit = totalCreditLimit - totalCreditUsed;

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Credit Cards</h1>
          <p className="text-gray-600">Manage your credit cards and payment history</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Card
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg" aria-describedby={undefined}>
            <DialogHeader className="pb-4 border-b">
              <DialogTitle className="text-gray-900">Add New Credit Card</DialogTitle>
              <p className="text-sm text-gray-600 mt-2">Add a new credit card to your account</p>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="cardName" className="text-gray-700">Card Name</Label>
                <Input
                  id="cardName"
                  value={formData.cardName}
                  onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                  placeholder="e.g., Chase Sapphire"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="last4Digits" className="text-gray-700">Last 4 Digits</Label>
                <Input
                  id="last4Digits"
                  value={formData.last4Digits}
                  onChange={(e) => setFormData({ ...formData, last4Digits: e.target.value })}
                  placeholder="1234"
                  maxLength={4}
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="issuer" className="text-gray-700">Issuer</Label>
                <Input
                  id="issuer"
                  value={formData.issuer}
                  onChange={(e) => setFormData({ ...formData, issuer: e.target.value })}
                  placeholder="e.g., Visa, Mastercard, Amex"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="creditLimit" className="text-gray-700">Credit Limit</Label>
                <Input
                  id="creditLimit"
                  type="number"
                  value={formData.creditLimit}
                  onChange={(e) => setFormData({ ...formData, creditLimit: e.target.value })}
                  placeholder="0.00"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currentBalance" className="text-gray-700">Current Used Balance</Label>
                <Input
                  id="currentBalance"
                  type="number"
                  value={formData.currentBalance}
                  onChange={(e) => setFormData({ ...formData, currentBalance: e.target.value })}
                  placeholder="0.00"
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dueDate" className="text-gray-700">Due Date</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>
            <div className="pt-4 border-t">
              <Button 
                onClick={handleAdd} 
                className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
              >
                Add Card
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Credit Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 mb-1">Total Credit Used</p>
            <p className="text-2xl text-purple-600">${totalCreditUsed.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 mb-1">Available Credit</p>
            <p className="text-2xl text-green-600">${availableCredit.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 mb-1">Total Credit Limit</p>
            <p className="text-2xl text-blue-600">${totalCreditLimit.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Cards List */}
      <div className="space-y-6">
        {cards.length === 0 ? (
          <Card className="shadow-sm">
            <CardContent className="p-12">
              <p className="text-center text-gray-500">No credit cards added yet</p>
            </CardContent>
          </Card>
        ) : (
          cards.map((card) => {
            const utilization = ((card.currentBalance / card.creditLimit) * 100).toFixed(1);
            const isHighUtilization = parseFloat(utilization) > 85;
            const isMediumUtilization = parseFloat(utilization) > 70 && parseFloat(utilization) <= 85;
            const isExpanded = expandedCards[card.id];
            
            // Combine payments and transactions into a unified history
            const combinedHistory = [
              ...card.payments.map(p => ({
                ...p,
                itemType: 'payment' as const,
                sortDate: new Date(p.date).getTime()
              })),
              ...card.transactions.map(t => ({
                ...t,
                itemType: 'transaction' as const,
                sortDate: new Date(t.date).getTime()
              }))
            ].sort((a, b) => b.sortDate - a.sortDate);
            
            const displayedHistory = showAllHistory[card.id]
              ? combinedHistory
              : combinedHistory.slice(0, 5);
            
            return (
              <Card 
                key={card.id} 
                className={`shadow-sm hover:shadow-md transition-shadow ${
                  isHighUtilization ? 'border-2 border-red-500' : ''
                }`}
              >
                {/* Compact header - always visible */}
                <CardContent className="p-5">
                  <div className="flex items-center justify-between gap-6">
                    {/* Left: Icon, Name, Type, Number */}
                    <div className="flex items-center gap-3">
                      <div className={`p-3 rounded-lg ${
                        isHighUtilization 
                          ? 'bg-red-600 text-white' 
                          : 'bg-gradient-to-br from-purple-600 to-blue-600 text-white'
                      }`}>
                        <CreditCardIcon className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-gray-900">{card.cardName}</p>
                          {isHighUtilization && (
                            <span className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              Critical
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{card.issuer} •••• {card.last4Digits}</p>
                      </div>
                    </div>
                    
                    {/* Center: Utilization bar */}
                    <div className="flex-1 max-w-md">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-gray-600">Utilization</span>
                        <span className={`text-xs ${
                          isHighUtilization ? 'text-red-600' : isMediumUtilization ? 'text-orange-600' : 'text-green-600'
                        }`}>
                          ${card.currentBalance.toLocaleString()} / ${card.creditLimit.toLocaleString()} ({utilization}%)
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div
                          className={`h-2.5 rounded-full transition-all ${
                            isHighUtilization ? 'bg-red-600' : isMediumUtilization ? 'bg-orange-600' : 'bg-purple-600'
                          }`}
                          style={{ width: `${utilization}%` }}
                        />
                      </div>
                    </div>
                    
                    {/* Payment Due Date */}
                    <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 rounded-lg">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <div>
                        <p className="text-xs text-gray-600">Due Date</p>
                        <p className="text-sm text-gray-900">{new Date(card.dueDate).toLocaleDateString()}</p>
                      </div>
                    </div>
                    
                    {/* Right: Action buttons and expand icon */}
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEditDialog(card)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(card.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      {combinedHistory.length > 0 && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setExpandedCards(prev => ({
                            ...prev,
                            [card.id]: !prev[card.id]
                          }))}
                          className="ml-2"
                        >
                          <Eye className="w-5 h-5 text-gray-600" />
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Warning messages */}
                  {isHighUtilization && (
                    <div className="flex items-start gap-2 p-3 bg-red-50 rounded-lg border border-red-200 mt-4">
                      <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-red-900">
                        ⚠️ Critical utilization alert - Consider making a payment immediately to reduce balance.
                      </p>
                    </div>
                  )}

                  {/* Expandable Payment & Transaction History */}
                  {isExpanded && combinedHistory.length > 0 && (
                    <div className="mt-6 pt-6 border-t space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-600">Payment & Transaction History</p>
                        {combinedHistory.length > 5 && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => toggleHistory(card.id)}
                            className="text-blue-600"
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            {showAllHistory[card.id] ? 'Show Less' : 'Show All'}
                          </Button>
                        )}
                      </div>
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {displayedHistory.map((item) => {
                          if (item.itemType === 'payment') {
                            return (
                              <div 
                                key={item.id} 
                                className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="p-2 bg-green-100 text-green-600 rounded-lg">
                                    <TrendingDown className="w-4 h-4" />
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-900">{item.description}</p>
                                    <p className="text-xs text-gray-600">{new Date(item.date).toLocaleDateString()}</p>
                                  </div>
                                </div>
                                <p className="text-green-600">-${item.amount.toLocaleString()}</p>
                              </div>
                            );
                          } else {
                            // Transaction
                            const transaction = item as typeof item & Transaction;
                            return (
                              <div 
                                key={transaction.id} 
                                className={`flex items-center justify-between p-3 rounded-lg ${
                                  transaction.type === 'credit' 
                                    ? 'bg-green-50 border border-green-200' 
                                    : 'bg-red-50 border border-red-200'
                                }`}
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`p-2 rounded-lg ${
                                    transaction.type === 'credit' 
                                      ? 'bg-green-100 text-green-600' 
                                      : 'bg-red-100 text-red-600'
                                  }`}>
                                    {transaction.type === 'credit' ? (
                                      <ArrowDownCircle className="w-4 h-4" />
                                    ) : (
                                      <ArrowUpCircle className="w-4 h-4" />
                                    )}
                                  </div>
                                  <div>
                                    <p className="text-sm text-gray-900">{transaction.description}</p>
                                    <p className="text-xs text-gray-600">{new Date(transaction.date).toLocaleDateString()}</p>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className={`text-sm ${
                                    transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {transaction.type === 'credit' ? '-' : '+'}${transaction.amount.toLocaleString()}
                                  </p>
                                  <p className="text-xs text-gray-600">
                                    Bal: ${transaction.balance.toLocaleString()}
                                  </p>
                                </div>
                              </div>
                            );
                          }
                        })}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-lg" aria-describedby={undefined}>
          <DialogHeader className="pb-4 border-b">
            <DialogTitle className="text-gray-900">Edit Credit Card</DialogTitle>
            <p className="text-sm text-gray-600 mt-2">Update your credit card information</p>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-cardName" className="text-gray-700">Card Name</Label>
              <Input
                id="edit-cardName"
                value={formData.cardName}
                onChange={(e) => setFormData({ ...formData, cardName: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-last4Digits" className="text-gray-700">Last 4 Digits</Label>
              <Input
                id="edit-last4Digits"
                value={formData.last4Digits}
                onChange={(e) => setFormData({ ...formData, last4Digits: e.target.value })}
                maxLength={4}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-issuer" className="text-gray-700">Issuer</Label>
              <Input
                id="edit-issuer"
                value={formData.issuer}
                onChange={(e) => setFormData({ ...formData, issuer: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-creditLimit" className="text-gray-700">Credit Limit</Label>
              <Input
                id="edit-creditLimit"
                type="number"
                value={formData.creditLimit}
                onChange={(e) => setFormData({ ...formData, creditLimit: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-currentBalance" className="text-gray-700">Current Used Balance</Label>
              <Input
                id="edit-currentBalance"
                type="number"
                value={formData.currentBalance}
                onChange={(e) => setFormData({ ...formData, currentBalance: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-dueDate" className="text-gray-700">Due Date</Label>
              <Input
                id="edit-dueDate"
                type="date"
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="h-11"
              />
            </div>
          </div>
          <div className="pt-4 border-t">
            <Button 
              onClick={handleEdit} 
              className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
            >
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}