import { useState } from 'react';
import { Income } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Plus, Pencil, Trash2, TrendingUp, CheckCircle, Clock, XCircle, RepeatIcon, CalendarCheck } from 'lucide-react';
import { Separator } from './ui/separator';

interface IncomesPageProps {
  incomes: Income[];
  setIncomes: (incomes: Income[]) => void;
}

export function IncomesPage({ incomes, setIncomes }: IncomesPageProps) {
  const [isAddRecurringOpen, setIsAddRecurringOpen] = useState(false);
  const [isAddOneTimeOpen, setIsAddOneTimeOpen] = useState(false);
  const [isEditSheetOpen, setIsEditSheetOpen] = useState(false);
  const [editingIncome, setEditingIncome] = useState<Income | null>(null);
  const [incomeType, setIncomeType] = useState<'recurring' | 'one-time'>('recurring');
  const [formData, setFormData] = useState({
    source: '',
    amount: '',
    frequency: 'monthly' as Income['frequency'],
    startDate: '',
    category: '',
    description: ''
  });

  const resetForm = () => {
    setFormData({
      source: '',
      amount: '',
      frequency: 'monthly',
      startDate: '',
      category: '',
      description: ''
    });
  };

  const handleAdd = () => {
    const newOccurrence: IncomeOccurrence = {
      id: `occ-${Date.now()}`,
      date: formData.startDate,
      expectedAmount: parseFloat(formData.amount),
      isConfirmed: false
    };

    const newIncome: Income = {
      id: Date.now().toString(),
      source: formData.source,
      amount: parseFloat(formData.amount),
      frequency: incomeType === 'one-time' ? 'one-time' : formData.frequency,
      startDate: formData.startDate,
      category: formData.category,
      description: formData.description,
      occurrences: [newOccurrence]
    };
    setIncomes([...incomes, newIncome]);
    setIsAddRecurringOpen(false);
    setIsAddOneTimeOpen(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!editingIncome) return;
    const updatedIncomes = incomes.map(income =>
      income.id === editingIncome.id
        ? {
            ...income,
            source: formData.source,
            amount: parseFloat(formData.amount),
            frequency: formData.frequency,
            startDate: formData.startDate,
            category: formData.category,
            description: formData.description
          }
        : income
    );
    setIncomes(updatedIncomes);
    setIsEditSheetOpen(false);
    setEditingIncome(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setIncomes(incomes.filter(income => income.id !== id));
  };

  const openEditSheet = (income: Income) => {
    setEditingIncome(income);
    setFormData({
      source: income.source,
      amount: income.amount.toString(),
      frequency: income.frequency,
      startDate: income.startDate,
      category: income.category,
      description: income.description
    });
    setIsEditSheetOpen(true);
  };

  const handleConfirmOccurrence = (incomeId: string, occurrenceId: string, receivedAmount: number) => {
    const updatedIncomes = incomes.map(income => {
      if (income.id === incomeId) {
        return {
          ...income,
          occurrences: income.occurrences.map(occ =>
            occ.id === occurrenceId
              ? { ...occ, isConfirmed: true, receivedAmount }
              : occ
          )
        };
      }
      return income;
    });
    setIncomes(updatedIncomes);
  };

  const recurringIncomes = incomes.filter(inc => inc.frequency !== 'one-time');
  const oneTimeIncomes = incomes.filter(inc => inc.frequency === 'one-time');

  const totalExpectedIncome = incomes.reduce((sum, income) => {
    const pendingOccurrences = income.occurrences.filter(occ => !occ.isConfirmed);
    return sum + pendingOccurrences.reduce((occSum, occ) => occSum + occ.expectedAmount, 0);
  }, 0);

  const totalReceivedIncome = incomes.reduce((sum, income) => {
    const confirmedOccurrences = income.occurrences.filter(occ => occ.isConfirmed);
    return sum + confirmedOccurrences.reduce((occSum, occ) => occSum + (occ.receivedAmount || occ.expectedAmount), 0);
  }, 0);

  const recurringTotal = recurringIncomes.reduce((sum, income) => sum + income.amount, 0);
  const oneTimeTotal = oneTimeIncomes.reduce((sum, income) => sum + income.amount, 0);

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-gray-900 mb-2">Income Management</h1>
          <p className="text-gray-600">Track and confirm your income sources</p>
        </div>
        <div className="flex gap-3">
          <Dialog open={isAddRecurringOpen} onOpenChange={setIsAddRecurringOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                onClick={() => setIncomeType('recurring')}
              >
                <RepeatIcon className="w-4 h-4 mr-2" />
                Add Recurring
              </Button>
            </DialogTrigger>
            <DialogContent className="overflow-y-auto max-w-lg" aria-describedby={undefined}>
              <DialogHeader className="pb-4 border-b">
                <DialogTitle className="text-gray-900">Add Recurring Income</DialogTitle>
                <p className="text-sm text-gray-600 mt-2">Add a new recurring income source to your account</p>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="source" className="text-gray-700">Source</Label>
                  <Input
                    id="source"
                    value={formData.source}
                    onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                    placeholder="e.g., Monthly Salary"
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount" className="text-gray-700">Amount</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0.00"
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="frequency" className="text-gray-700">Frequency</Label>
                  <Select
                    value={formData.frequency}
                    onValueChange={(value) => setFormData({ ...formData, frequency: value })}
                  >
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="bi-weekly">Bi-weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status" className="text-gray-700">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="received">Received</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="pt-4 border-t">
                <Button 
                  onClick={handleAdd} 
                  className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
                >
                  Add Recurring Income
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddOneTimeOpen} onOpenChange={setIsAddOneTimeOpen}>
            <DialogTrigger asChild>
              <Button 
                variant="outline"
                className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50"
                onClick={() => setIncomeType('one-time')}
              >
                <CalendarCheck className="w-4 h-4 mr-2" />
                Add One-Time
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg" aria-describedby={undefined}>
              <DialogHeader className="pb-4 border-b">
                <DialogTitle className="text-gray-900">Add One-Time Income</DialogTitle>
                <p className="text-sm text-gray-600 mt-2">Add a one-time income source to your account</p>
              </DialogHeader>
              <div className="space-y-5 py-4">
                <div className="space-y-2">
                  <Label htmlFor="source-onetime" className="text-gray-700">Income Source</Label>
                  <Input
                    id="source-onetime"
                    value={formData.source}
                    onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                    placeholder="e.g., Freelance Project"
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount-onetime" className="text-gray-700">Amount</Label>
                  <Input
                    id="amount-onetime"
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0.00"
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="startDate-onetime" className="text-gray-700">Payment Date</Label>
                  <Input
                    id="startDate-onetime"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="h-11"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category-onetime" className="text-gray-700">Category</Label>
                  <Input
                    id="category-onetime"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    placeholder="e.g., Freelance, Gift, Bonus"
                    className="h-11"
                  />
                </div>
              </div>
              <div className="pt-4 border-t">
                <Button 
                  onClick={handleAdd} 
                  className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
                >
                  Add One-Time Income
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Income Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Expected Income</p>
                <p className="text-2xl text-blue-600">${totalExpectedIncome.toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-1">Pending</p>
              </div>
              <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                <Clock className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Received Income</p>
                <p className="text-2xl text-green-600">${totalReceivedIncome.toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-1">Confirmed</p>
              </div>
              <div className="bg-green-100 text-green-600 p-3 rounded-lg">
                <TrendingUp className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Recurring</p>
                <p className="text-2xl text-purple-600">${recurringTotal.toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-1">{recurringIncomes.length} sources</p>
              </div>
              <div className="bg-purple-100 text-purple-600 p-3 rounded-lg">
                <RepeatIcon className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">One-Time</p>
                <p className="text-2xl text-orange-600">${oneTimeTotal.toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-1">{oneTimeIncomes.length} sources</p>
              </div>
              <div className="bg-orange-100 text-orange-600 p-3 rounded-lg">
                <CalendarCheck className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recurring Incomes Section */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <RepeatIcon className="w-5 h-5 text-purple-600" />
          <h2 className="text-gray-900">Recurring Incomes</h2>
        </div>
        <div className="space-y-4">
          {recurringIncomes.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="p-12">
                <p className="text-center text-gray-500">No recurring income sources added yet</p>
              </CardContent>
            </Card>
          ) : (
            recurringIncomes.map((income) => (
              <Card key={income.id} className="shadow-sm">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {income.source}
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                          <RepeatIcon className="w-3 h-3" />
                          {income.frequency}
                        </span>
                      </CardTitle>
                      <p className="text-sm text-gray-600 mt-1">
                        {income.category} • ${income.amount.toLocaleString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEditSheet(income)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(income.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-600">Payment History:</p>
                    {income.occurrences.map((occurrence) => (
                      <ConfirmIncomeOccurrence
                        key={occurrence.id}
                        occurrence={occurrence}
                        onConfirm={(amount) => handleConfirmOccurrence(income.id, occurrence.id, amount)}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <Separator className="my-8" />

      {/* One-Time Incomes Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <CalendarCheck className="w-5 h-5 text-orange-600" />
          <h2 className="text-gray-900">One-Time Incomes</h2>
        </div>
        <div className="space-y-4">
          {oneTimeIncomes.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="p-12">
                <p className="text-center text-gray-500">No one-time income sources added yet</p>
              </CardContent>
            </Card>
          ) : (
            oneTimeIncomes.map((income) => (
              <Card key={income.id} className="shadow-sm">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {income.source}
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded">
                          <CalendarCheck className="w-3 h-3" />
                          one-time
                        </span>
                      </CardTitle>
                      <p className="text-sm text-gray-600 mt-1">
                        {income.category} • ${income.amount.toLocaleString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEditSheet(income)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(income.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {income.occurrences.map((occurrence) => (
                      <ConfirmIncomeOccurrence
                        key={occurrence.id}
                        occurrence={occurrence}
                        onConfirm={(amount) => handleConfirmOccurrence(income.id, occurrence.id, amount)}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Edit Sheet */}
      <Dialog open={isEditSheetOpen} onOpenChange={setIsEditSheetOpen}>
        <DialogContent className="max-w-lg" aria-describedby={undefined}>
          <DialogHeader className="pb-4 border-b">
            <DialogTitle className="text-gray-900">Edit Income</DialogTitle>
            <p className="text-sm text-gray-600 mt-2">Update the details of this income source</p>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-source" className="text-gray-700">Source</Label>
              <Input
                id="edit-source"
                value={formData.source}
                onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-amount" className="text-gray-700">Amount</Label>
              <Input
                id="edit-amount"
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-frequency" className="text-gray-700">Frequency</Label>
              <Select value={formData.frequency} onValueChange={(value) => setFormData({ ...formData, frequency: value as Income['frequency'] })}>
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                  <SelectItem value="one-time">One-time</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-startDate" className="text-gray-700">Payment Date</Label>
              <Input
                id="edit-startDate"
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-category" className="text-gray-700">Category</Label>
              <Input
                id="edit-category"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="h-11"
              />
            </div>
          </div>
          <div className="pt-4 border-t">
            <Button 
              onClick={handleEdit} 
              className="w-full h-11 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-md"
            >
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ConfirmIncomeOccurrence({ 
  occurrence, 
  onConfirm 
}: { 
  occurrence: IncomeOccurrence; 
  onConfirm: (amount: number) => void;
}) {
  const [isConfirming, setIsConfirming] = useState(false);
  const [amount, setAmount] = useState(occurrence.expectedAmount.toString());

  if (occurrence.isConfirmed) {
    return (
      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
        <div className="flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <div>
            <p className="text-sm text-gray-900">{new Date(occurrence.date).toLocaleDateString()}</p>
            <p className="text-xs text-gray-600">
              Received: ${occurrence.receivedAmount?.toLocaleString() || occurrence.expectedAmount.toLocaleString()}
            </p>
          </div>
        </div>
        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Confirmed</span>
      </div>
    );
  }

  if (isConfirming) {
    return (
      <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
        <div className="flex-1">
          <Label htmlFor={`amount-${occurrence.id}`} className="text-xs">Received Amount</Label>
          <Input
            id={`amount-${occurrence.id}`}
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1"
          />
        </div>
        <div className="flex gap-1">
          <Button
            size="sm"
            onClick={() => {
              onConfirm(parseFloat(amount));
              setIsConfirming(false);
            }}
            className="bg-green-600 hover:bg-green-700"
          >
            <CheckCircle className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setIsConfirming(false)}
          >
            <XCircle className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
      <div className="flex items-center gap-3">
        <Clock className="w-5 h-5 text-yellow-600" />
        <div>
          <p className="text-sm text-gray-900">{new Date(occurrence.date).toLocaleDateString()}</p>
          <p className="text-xs text-gray-600">Expected: ${occurrence.expectedAmount.toLocaleString()}</p>
        </div>
      </div>
      <Button
        size="sm"
        onClick={() => setIsConfirming(true)}
        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
      >
        Confirm
      </Button>
    </div>
  );
}