import { Income, Expense, BankAccount, CreditCard } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { TrendingUp, TrendingDown, DollarSign, AlertCircle, CheckCircle, Clock, Calendar } from 'lucide-react';
import { useState } from 'react';

interface DashboardProps {
  incomes: Income[];
  expenses: Expense[];
  bankAccounts: BankAccount[];
  creditCards: CreditCard[];
  setIncomes: (incomes: Income[]) => void;
  setExpenses: (expenses: Expense[]) => void;
}

export function Dashboard({ incomes, expenses, bankAccounts, creditCards, setIncomes, setExpenses }: DashboardProps) {
  // Month/Year selector state
  const [selectedMonth, setSelectedMonth] = useState(10); // November (0-indexed)
  const [selectedYear, setSelectedYear] = useState(2025);

  // Get current month data
  const currentDate = new Date('2025-11-07'); // Using fixed date for demo
  const currentMonth = selectedMonth;
  const currentYear = selectedYear;

  // Generate month options
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Generate year options (5 years in past, 2 years in future)
  const currentActualYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 8 }, (_, i) => currentActualYear - 5 + i);

  // Filter current month occurrences
  const currentMonthIncomeOccurrences = incomes.flatMap(income => 
    income.occurrences.filter(occ => {
      const occDate = new Date(occ.date);
      return occDate.getMonth() === currentMonth && occDate.getFullYear() === currentYear;
    }).map(occ => ({ ...occ, source: income.source, incomeId: income.id }))
  );

  const currentMonthExpenses = expenses.filter(expense => {
    const expDate = new Date(expense.date);
    return expDate.getMonth() === currentMonth && expDate.getFullYear() === currentYear;
  });

  // Calculate stats
  const expectedIncome = currentMonthIncomeOccurrences.reduce((sum, occ) => sum + occ.expectedAmount, 0);
  const receivedIncome = currentMonthIncomeOccurrences
    .filter(occ => occ.isConfirmed)
    .reduce((sum, occ) => sum + (occ.receivedAmount || occ.expectedAmount), 0);

  const expectedExpenses = currentMonthExpenses.reduce((sum, exp) => sum + exp.amount, 0);
  const paidExpenses = currentMonthExpenses
    .filter(exp => exp.isPaid)
    .reduce((sum, exp) => sum + exp.amount, 0);

  const totalBankBalance = bankAccounts.reduce((sum, account) => sum + account.balance, 0);
  const netBalance = receivedIncome - paidExpenses;

  // Pending events
  const pendingEvents: Array<{
    id: string;
    type: 'income' | 'expense';
    description: string;
    amount: number;
    date: string;
    action?: () => void;
  }> = [];

  // Add pending income confirmations
  currentMonthIncomeOccurrences
    .filter(occ => !occ.isConfirmed)
    .forEach(occ => {
      pendingEvents.push({
        id: occ.id,
        type: 'income',
        description: `Confirm ${occ.source}`,
        amount: occ.expectedAmount,
        date: occ.date,
        action: () => handleConfirmIncome(occ.incomeId, occ.id)
      });
    });

  // Add pending expenses
  currentMonthExpenses
    .filter(exp => !exp.isPaid)
    .forEach(exp => {
      pendingEvents.push({
        id: exp.id,
        type: 'expense',
        description: exp.description,
        amount: exp.amount,
        date: exp.date,
        action: () => handlePayExpense(exp.id)
      });
    });

  // Sort by overdue first, then by date
  pendingEvents.sort((a, b) => {
    const dateA = new Date(a.date);
    const dateB = new Date(b.date);
    const isOverdueA = dateA < currentDate;
    const isOverdueB = dateB < currentDate;
    
    // Overdue events first
    if (isOverdueA && !isOverdueB) return -1;
    if (!isOverdueA && isOverdueB) return 1;
    
    // Then sort by date
    return dateA.getTime() - dateB.getTime();
  });

  // Completed events
  const completedEvents: Array<{
    id: string;
    type: 'income' | 'expense';
    description: string;
    amount: number;
    date: string;
  }> = [];

  // Add confirmed income occurrences
  currentMonthIncomeOccurrences
    .filter(occ => occ.isConfirmed)
    .forEach(occ => {
      completedEvents.push({
        id: occ.id,
        type: 'income',
        description: occ.source,
        amount: occ.receivedAmount || occ.expectedAmount,
        date: occ.date
      });
    });

  // Add paid expenses
  currentMonthExpenses
    .filter(exp => exp.isPaid)
    .forEach(exp => {
      completedEvents.push({
        id: exp.id,
        type: 'expense',
        description: exp.description,
        amount: exp.amount,
        date: exp.date
      });
    });

  // Sort completed events by date (most recent first)
  completedEvents.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleConfirmIncome = (incomeId: string, occurrenceId: string) => {
    const updatedIncomes = incomes.map(income => {
      if (income.id === incomeId) {
        return {
          ...income,
          occurrences: income.occurrences.map(occ => 
            occ.id === occurrenceId 
              ? { ...occ, isConfirmed: true, receivedAmount: occ.expectedAmount }
              : occ
          )
        };
      }
      return income;
    });
    setIncomes(updatedIncomes);
  };

  const handlePayExpense = (expenseId: string) => {
    const updatedExpenses = expenses.map(expense =>
      expense.id === expenseId ? { ...expense, isPaid: true } : expense
    );
    setExpenses(updatedExpenses);
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-gray-900 mb-2">Dashboard</h1>
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-gray-600" />
          <div className="flex items-center gap-2">
            <Select 
              value={selectedMonth.toString()} 
              onValueChange={(value) => setSelectedMonth(parseInt(value))}
            >
              <SelectTrigger className="w-[140px] h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {monthNames.map((month, index) => (
                  <SelectItem key={index} value={index.toString()}>
                    {month}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select 
              value={selectedYear.toString()} 
              onValueChange={(value) => setSelectedYear(parseInt(value))}
            >
              <SelectTrigger className="w-[100px] h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {yearOptions.map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <span className="text-gray-600">Financial Overview</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm text-gray-600 mb-1">Income</p>
                <div className="space-y-1">
                  <div className="flex items-baseline gap-2">
                    <p className="text-2xl text-green-600">${receivedIncome.toLocaleString()}</p>
                    <p className="text-sm text-gray-500">/ ${expectedIncome.toLocaleString()}</p>
                  </div>
                  <p className="text-xs text-gray-500">Received vs Expected</p>
                </div>
              </div>
              <div className="bg-green-100 text-green-600 p-3 rounded-lg">
                <TrendingUp className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm text-gray-600 mb-1">Expenses</p>
                <div className="space-y-1">
                  <div className="flex items-baseline gap-2">
                    <p className="text-2xl text-red-600">${paidExpenses.toLocaleString()}</p>
                    <p className="text-sm text-gray-500">/ ${expectedExpenses.toLocaleString()}</p>
                  </div>
                  <p className="text-xs text-gray-500">Paid vs Expected</p>
                </div>
              </div>
              <div className="bg-red-100 text-red-600 p-3 rounded-lg">
                <TrendingDown className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Available Balance</p>
                <p className="text-2xl text-blue-600">${totalBankBalance.toLocaleString()}</p>
              </div>
              <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                <DollarSign className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Net Balance</p>
                <p className={`text-2xl ${netBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ${netBalance.toLocaleString()}
                </p>
                <p className="text-xs text-gray-500 mt-1">This month</p>
              </div>
              <div className={`${netBalance >= 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'} p-3 rounded-lg`}>
                <DollarSign className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Events */}
      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Pending & Upcoming Events</CardTitle>
            <span className="text-sm text-gray-600">{pendingEvents.length} items</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {pendingEvents.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <p className="text-gray-600">All caught up! No pending events.</p>
              </div>
            ) : (
              pendingEvents.map((event) => {
                const eventDate = new Date(event.date);
                const isOverdue = eventDate < currentDate;
                const isToday = eventDate.toDateString() === currentDate.toDateString();

                return (
                  <div 
                    key={event.id} 
                    className={`flex items-center justify-between p-4 rounded-lg border-l-4 ${
                      isOverdue 
                        ? 'bg-red-50 border-red-500' 
                        : isToday
                        ? 'bg-yellow-50 border-yellow-500'
                        : 'bg-gray-50 border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className={`p-2 rounded-lg ${
                        event.type === 'income' 
                          ? 'bg-green-100 text-green-600' 
                          : 'bg-red-100 text-red-600'
                      }`}>
                        {event.type === 'income' ? (
                          <TrendingUp className="w-5 h-5" />
                        ) : (
                          <TrendingDown className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-gray-900">{event.description}</p>
                          {isOverdue && (
                            <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs rounded">Overdue</span>
                          )}
                          {isToday && (
                            <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded">Today</span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1">
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {eventDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </p>
                          <p className={`text-sm ${
                            event.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {event.type === 'income' ? '+' : '-'}${event.amount.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                    {event.action && (
                      <Button 
                        size="sm"
                        onClick={event.action}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        {event.type === 'income' ? 'Confirm' : 'Mark as Paid'}
                      </Button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      {/* Completed Events */}
      <Card className="shadow-sm mt-8">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Completed Events</CardTitle>
            <span className="text-sm text-gray-600">{completedEvents.length} items</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {completedEvents.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                <p className="text-gray-600">No completed events.</p>
              </div>
            ) : (
              completedEvents.map((event) => {
                const eventDate = new Date(event.date);
                const isToday = eventDate.toDateString() === currentDate.toDateString();

                return (
                  <div 
                    key={event.id} 
                    className={`flex items-center justify-between p-4 rounded-lg border-l-4 ${
                      isToday
                        ? 'bg-yellow-50 border-yellow-500'
                        : 'bg-gray-50 border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className={`p-2 rounded-lg ${
                        event.type === 'income' 
                          ? 'bg-green-100 text-green-600' 
                          : 'bg-red-100 text-red-600'
                      }`}>
                        {event.type === 'income' ? (
                          <TrendingUp className="w-5 h-5" />
                        ) : (
                          <TrendingDown className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-gray-900">{event.description}</p>
                          {isToday && (
                            <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-xs rounded">Today</span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1">
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {eventDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </p>
                          <p className={`text-sm ${
                            event.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {event.type === 'income' ? '+' : '-'}${event.amount.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}